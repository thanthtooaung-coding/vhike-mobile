package com.vinn.vhike.di

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class VhikeApplication : Application() {

}